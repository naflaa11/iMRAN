# -*- coding: utf-8 -*-
{
    'name': "AFCC Invoice",
    'summary': """
        AFCC Invoice""",
    'description': """
        AFCC Invoice
    """,
    'author': "Magdy, helcon",
    'website': "https://telenoc.org",
    'category': 'Account',
    'version': '0.1',
    'depends': ['web', 'account'],
    'data': [
        # 'views/account_invoice.xml',
        # 'report/sales_report.xml',
        'report/invoice_report.xml',
    ],
}
